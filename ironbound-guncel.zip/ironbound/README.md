# IRONBOUND 3D — Zırhlı Muharebe

War Thunder esintili tarayıcı tank oyunu (three.js r128). Tek oyunculu, 5'e 5 yapay zekâ takımlarıyla **hakimiyet** modu: A/B/C noktalarını tut, düşman biletlerini erit.

## Araçlar
- **M1A2 Abrams** — 120 mm M256, APFSDS (M829A2) ve HEAT-FS (M830A1). Kompozit taret önü çok güçlü; üst ön plaka, taret yanları/arkası zayıf.
- **M2A3 Bradley** — 25 mm M242 (çift besleme: APFSDS / HEI-T) + TOW-2 tanksavar füzesi (durarak ateşlenir, nişan imleciyle güdülür).

Kadronda iki araç vardır; biri imha edilirse diğeriyle sahaya dönersin.

## Oynanış
- Gerçek namlu çıkış hızları, yer çekimi ve sürtünmeli balistik
- Açıya bağlı zırh delme, sekme, aralıklı zırh (palet), iç parçalanma (spall)
- Modül ve mürettebat hasarı: motor, şanzıman, paletler, top kamarası, mühimmat (infilak = taret uçar), yakıt yangını; HP çubuğu yok
- Vuruş kamerası, hasar şeması, menzil ölçerli nişangâh, mini harita, imha akışı, skor tablosu

## Kontroller
W/S gaz-geri · A/D dönüş · Fare nişan · Sol tık / Space ateş · Sağ tık / Shift nişangâh · Tekerlek yakınlaştır · 1-2-3 mühimmat · R hızlı doldur · X onarım · F yangın söndür · C serbest bakış · Tab skor · Esc duraklat
Tablet: sol başparmak sür, sağ yarı nişan; ATEŞ / NİŞAN / MÜHİMMAT / ONAR / SÖNDÜR düğmeleri.

## Çalıştırma
Modeller `fetch` ile yüklendiği için `index.html`'e çift tıklayarak (file://) **açılmaz**. GitHub Pages'te doğrudan çalışır; yerelde:
```
python -m http.server 8000
```
sonra `http://localhost:8000`.

## Dosyalar
- `index.html` — arayüz ve ekranlar
- `js/game.js` — oyunun tamamı
- `assets/models/*.glb` — FBX'ten dönüştürülmüş, taret/top/palet parçaları ayrılmış modeller
- `assets/tex/*.jpg` — 2K (yüksek) ve 1K `_lq` (düşük grafik) dokular; ORM = R:1, G:pürüzlülük, B:metalik
